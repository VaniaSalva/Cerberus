


<?php $__env->startSection('title', 'Institución Policial Estatal Fuerza Civil'); ?>

<?php $__env->startSection('content_header'); ?>
   <center> <h1>Mesa de personal</h1> </center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script> console.log('Hi'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WorkSpace\Cerberus\resources\views/Crud/Personal.blade.php ENDPATH**/ ?>