


<?php $__env->startSection('title', 'Relacion de personal'); ?>

<?php $__env->startSection('content_header'); ?>
   <center> <h1>Relacion de personal</h1> </center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="container">
        <table id="exportable" class="table table-striped table-responsive" style="width: 100%">
            <thead>
                <tr>
                    <th>No. Organico</th>
                    <th>No. Emp.</th>
                    <th>Grado</th>
                    <th>Nombre</th>
                    <th>P. Apellido</th>
                    <th>S. Apellido</th>
                    <th>Adscripción</th>
                    <th>Alta ADS</th>
                    <th>Apartado</th>
                    <th>Adscrip. Anterior</th>
                    <th>Alta ADS</th>
                    <th>Cargo</th>
                    <th>Tipo Ingreso</th>
                    <th>Estatus Nominal</th>
                    <th>Rol</th>
                    <th>Genero</th>
                    <th>Fecha Ingreso</th>
                    <th style="width: 300px">Fecha Ingreso A Campo</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if(!isset($empleado->isBaja)): ?>
            
                 <tr>
                        <td>
                            <?php echo e($empleado->num_org ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->num_emp ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->grado ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->nombre ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->primer_apellido ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->segundo_apellido ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->alta ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e(date('d/m/Y',strtotime($empleado->fecha_ingreso))
                            ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e($empleado->funcion ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e($empleado->adscripcion ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e(date('d/m/Y',strtotime($empleado->fecha)) ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e($empleado->cargo ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e($empleado->tipo_ingresos ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e('ACTIVO'); ?>

                        </td>
                        <td>
                            <?php echo e($empleado->bloque ?? 'No se econtró este dato'); ?>

                        </td>
                         <td>
                            <?php echo e($empleado->genero ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e(date('d/m/Y',strtotime($empleado->fecha_ingreso)) ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e(date('d/m/Y',strtotime($empleado->fecha_ingresi_fc)) ?? 'No se econtró este dato'); ?>

                        </td>
                        <td>
                            <?php echo e($empleado->estado ?? 'No se econtró este dato'); ?>

                        </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="18" class="text-center">
                            No hay registros.
                        </td>
                    </tr>
            
            <?php endif; ?>
            </tbody>
        </table>
    </div>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<style>
    .left-col {
    float: left;
    width: 25%;
}
 
.center-col {
    width: 50%;
}
 
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script>
   


$(document).ready(function () {
$('#exportable').DataTable({
ordering: true,
info: false,
language: {
    url: 'https://cdn.datatables.net/plug-ins/1.12.1/i18n/es-MX.json'
},
"pageLength": 5,
"bLengthChange": false,
"pagingType": "full_numbers",
dom: '<"top"<"left-col"B><"center-col"l><"right-col"f>>rtip',
buttons: [
    {
        extend: 'excel',
        title: 'Relacion de personal',
        text: 'Exportar',
        className: 'btn btn-primary'
    }
]
});
});

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WorkSpace\Cerberus\resources\views/empleados/index.blade.php ENDPATH**/ ?>