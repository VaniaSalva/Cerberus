@extends('adminlte::page')


@section('title', 'Institución Policial Estatal Fuerza Civil')

@section('content_header')
   <center> <h1>Mesa de Loc</h1> </center>
@stop

@section('content')
<p></p>
@stop

@section('css')
<link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
<script> console.log('Hi'); </script>
@stop
